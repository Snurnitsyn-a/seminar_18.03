## Основные команды первого семинара по git

> **git init** - *инициализация локального репозитория*

> **git status** - *получить информацию о текущем состоянии*

> **git add** - *добавить файлы к следующему коммиту*

> **git log** - *посмотреть журнал коммитов*

![Картинка не открылась](https://artsdot.com/ADC/Art-ImgScreen-4.nsf/O/A-9H5R2C/$FILE/Wassily-kandinsky-transverse-line.Jpg)

[Geek Brains](https://gb.ru/education_new)

```python
numbers = [2, 5, 13, 7, 6, 4]
size = 6
sum = 0
avg = 0
index = 0
while index < size:
    sum =+ numbers[index]
    index += 1 
avg = sum / size
print(avg)
```
1. Пронумерованный элемент 1
2. Пронумерованный элемент 2 